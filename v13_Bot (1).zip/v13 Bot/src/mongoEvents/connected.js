module.exports = {
	name: 'connected',
	async execute() {
		console.log("Connected to database.");
	},
};