module.exports = {
	name: 'disconnected',
	async execute() {
		console.log("Disconnected from database.");
	},
};